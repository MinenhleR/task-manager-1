# import the tabulate module for table formatting
from tabulate import tabulate

# define the shoe class to represent its attributes 
class Shoe:
    # initailize shoe attributes
    def __init__(self, country, code, product, cost, quantity):
        self.country = country
        self.code = code
        self.product = product
        self.cost = cost
        self.quantity = quantity
    
    # get cost of shoe 
    def get_cost(self):
       return self.cost
    
    # get quantity of shoe 
    def get_quantity(self):
        return self.quantity
    
    # represent a shoe as a string
    def __str__(self):
        return f"Country: {self.country}, Code: {self.code}, Product: {self.product}, Cost: {self.cost}, Quantity: {self.quantity}"

# create a variable with an empty list to store a list of shoes 
shoe_list = []

# function to read data and create shoes object from the data in inventory.txt file 
def read_shoes_data():
    try:
        # open inventory teext file in read mode 
        file = open("inventory.txt", "r")
        lines = file.readlines()

        # skip first line using slicing
        lines = lines[1:]

        # iterarte through each line in the inventory text file
        for line in file:
            data = line.strip().split(", ")
            if len(data) == 5:
                country, code, product, cost, quantity = data
                shoe = Shoe(country, code, product, float(cost), int(quantity))
                shoe_list.append(shoe)
            else:
                print(f"Invalid data: {line}")
        # close inventory text file
        file.close()
    except FileNotFoundError:
        print("Inventory text file not found.")

# function to capture users data about a shoe
def capture_shoes():
    country = input("Please enter the country: ")
    code = input("Please enter code: ")
    product = input("Please enter the product: ")
    cost = float(input("Please enter the cost: "))
    quantity = int(input("Please enter quantity: "))

    # create a shoe object and add to the list
    shoe = shoe(country, code, product, cost, quantity)
    shoe_list.append(shoe)
    print("Data captured successfully ! ")

# function that will iterate over shoe list 
def view_all():
    if not shoe_list:
        print("No shoes in stock.")
    else: 
        table_format = []
        for shoe in shoe_list:
            table_format.append([shoe.country, shoe.code, shoe.prooduct, shoe.cost, shoe.quantity])
        captions = ["Country", "Code", "Product", "Cost", "Quantity"]
        # use tabulate module to display data in a table
        print(tabulate(table_format, headers=captions, tablefmt="grid"))

# function to re-stock shoes with lowest quantity
def re_stock():
    if not shoe_list:
        print("No shoes in stock.")
        return
    
    # initialize positive infinity
    lowest_quantity = float("inf")
    lowest_quantity_shoe = None

    for shoe in shoe_list:
        if shoe.quantity < lowest_quantity:
            lowest_quantity = shoe.quantitty
            lowest_quantity_shoe = shoe

    if lowest_quantity_shoe:
        print(f"The shoe with the lowest quantity is: {lowest_quantity_shoe.product} {lowest_quantity_shoe.code} - Quantity: {lowest_quantity_shoe.quantity}")
    

    try:
        add_quantity = int(input("Please enter the quantity of shoes to be re-stocked {lowest_quantity_shoe.product}:"))
        lowest_quantity_shoe.quantity += add_quantity
        print(f"The new quantity of shoes: {lowest_quantity_shoe.quantity}")

        try:
            # open inventory text file on read mode 
            file = open("inventory.txt", "r")
            lines = file.readlines()
            file.close()

            # update qunatity in the file 
            for i, line in enumerate(lines):
                if lowest_quantity_shoe.code in line:
                    line = line.replace(str(lowest_quantity_shoe.quantity - add_quantity), str(lowest_quantity_shoe.quantity))
                    lines[i] = line

            # open inventory text file in write mode 
            file = open("inventory.txt", "w")
            file.writelines(lines)
            file.close()
        except FileNotFoundError:
            print("Inventory text file not found")
    except ValueError:
        print("Invalid input.")
    else:
        print("No shoes found.")

# function to search for shoe from the list using shoe code 
def search_shoe():
    code = input("Please enter the code of the shoe: ")
    found = False 
    for shoe in shoe_list:
        if shoe.code == code:
            print(f"Code of shoe {shoe}")
            found = True
            break
        if not found:
            print(f"Shoe with code {code} not in inventory.")

#  function that will calculate the total value of each item 
def value_per_item():
    if not shoe_list:
        print("No shoes in stock.")

    print("Value per item:")
    for shoe in shoe_list:
        value = shoe.cost * shoe.quantity
        print(f"{shoe.product} ({shoe.code}) - Total Value: {value}")

# function to the product with highest quantity 
def highest_qty(): 
    if not shoe_list:
        print("No shoes in stock.")
        return
    
    highest_quantity = 0
    highest_quantity_shoe = None

    for shoe in shoe_list:
        if shoe.quantity > highest_quantity:
            highest_quantity = shoe.quantitty
            highest_quantity_shoe = shoe

    if highest_quantity_shoe:
        print(f"The shoe with the quantity is: {highest_quantity_shoe.product} {highest_quantity_shoe.code}")
    else:
        print(f"No shoe found.")
    
    # find the shoe with highest quantity
   

# loop for main menu 
print("Welcome to the Shoe Inventory Menu")
while True:
    print()
    menu = input('''Select one of the following Options below:
    1. Read Shoe Data
    2. Capture Shoe Data
    3. View All Shoes
    4. View Shoes That Need To Be Re-stocked
    5. Search For Shoe
    6. Calculate Total Value Per Item
    7. Find Shoe With Highest Quantity
    8. Exit
: ''')

    if menu == "1":
        read_shoes_data()
    elif menu == "2":
        capture_shoes()
    elif menu == "3":
        view_all()
    elif menu == "4":
        re_stock()
    elif menu == "5":
        search_shoe()
    elif menu == "6":
        value_per_item()
    elif menu == "7":
        highest_qty()
    elif menu == "8":
        print("Exit.")
        break
    else:
        print("Invalid choice, please choose between 1-8: ")
print()
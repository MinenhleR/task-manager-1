# A program that will be used by a bookstore clerk

# Define a class for books 
class Book:
    def __init__(self, id, title, author, quantity):
        self.id = id
        self.title = title
        self.author = author
        self.quantity = quantity

# Define a class for the bookstore and its operations 
class Bookstore:
    def __init__(self):
        self.books = []

    def add_book(self, book):
        self.books.append(book)

# Update book information when id is found 
    def update_book(self, book_id, new_title, new_author, new_quantity):
        for book in self.books:
            if book.id == book_id:
                book.title = new_title
                book.author = new_author
                book.quantity = new_quantity
                print("Book updated successfully.")
                return
        print("Book not found.")

# Delete a book based on its id 
    def delete_book(self, book_id):
        for book in self.books:
            if book.id == book_id:
                self.books.remove(book)
                print("Book deleted successfully.")
                return
        print("Book not found.")

# Search for the book by its title 
    def search_book(self, title):
        for book in self.books:
            if book.title.lower() == title.lower():
                print(f"Book found - ID: {book.id}, Title: {book.title}, Author: {book.author}, Quantity: {book.quantity}")
                return
        print("Book not found.")

# Dispaly the books in the bookstore 
    def display_books(self):
        print("\nID\tTitle\tAuthor\tQuantity")
        for book in self.books:
            print(f"{book.id}\t{book.title}\t{book.author}\t{book.quantity}")
        print()

# Display menu option
def main():
    bookstore = Bookstore()

    while True:
        print("\nMenu:")
        print("1. Enter book")
        print("2. Update book")
        print("3. Delete book")
        print("4. Search books")
        print("0. Exit")
        
        # Ask for user input 
        choice = input("Enter your choice: ")

        if choice == "1":
            id = input("Enter book ID: ")
            title = input("Enter book title: ")
            author = input("Enter book author: ")
            quantity = input("Enter book quantity: ")
            new_book = Book(id, title, author, quantity)
            bookstore.add_book(new_book)
            print("Book added successfully.")

        elif choice == "2":
            book_id = input("Enter book ID to update: ")
            new_title = input("Enter new title: ")
            new_author = input("Enter new author: ")
            new_quantity = input("Enter new quantity: ")
            bookstore.update_book(book_id, new_title, new_author, new_quantity)

        elif choice == "3":
            book_id = input("Enter book ID to delete: ")
            bookstore.delete_book(book_id)

        elif choice == "4":
            search_title = input("Enter book title to search: ")
            bookstore.search_book(search_title)

        elif choice == "0":
            print("Exiting program. Goodbye!")
            break

        else:
            print("Invalid choice. Please enter a valid option.")
        bookstore.display_books()


if __name__ == "__main__":
    main()
